# shared-target
 FoundryVTT module to share a token's targets across players
